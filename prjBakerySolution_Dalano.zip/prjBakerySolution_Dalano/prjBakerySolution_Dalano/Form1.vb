﻿Public Class Form1

    Private Sub BtnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim totalItems = Val(txtDoughnuts.Text) + Val(txtMuffins.Text)
        txtTotalItems.Text = totalItems
        Dim totalSales = totalItems * 25
        txtTotalSales.Text = Format(totalSales, "currency")
    End Sub

    Private Sub BtnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        btnCalc.Hide()
        btnClear.Hide()
        btnExit.Hide()
        printReceipt.Print()
        btnCalc.Show()
        btnClear.Show()
        btnExit.Show()
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtDoughnuts.Clear()
        txtMuffins.Clear()
        txtTotalItems.Clear()
        txtTotalSales.Clear()
        txtDoughnuts.Focus()



    End Sub
End Class
