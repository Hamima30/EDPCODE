﻿' Name:         Sunnyside Project
' Purpose:      Displays the number of square feet of material and the cost
' Programmer:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Public Class Rectangle
        Private _intLenght As Integer
        Private _intWidth As Integer
        Public Property Lenght As Integer
            Get
                Return _intLenght

            End Get
            Set(value As Integer)
                If value > 0 Then
                    _intLenght = value
                Else
                    _intLenght = 0
                End If

            End Set
        End Property
        Public Property Width As Integer
            Get
                Return _intWidth
            End Get
            Set(value As Integer)
                If value > 0 Then
                    _intWidth = value
                Else
                    _intWidth = 0
                End If
            End Set
        End Property
        Public Sub New()
            _intLenght = 0
            _intWidth = 0
        End Sub
        'Public Sub New(ByVal intL As Integer, ByVal intW As Integer)
        'Lenght = intL
        'Width = intW
        'End Sub
        Public Function GetArea() As Integer
            Return _intLenght * _intWidth
        End Function
    End Class

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' displays square feet and deck cost

        ' instantiate a Rectangle object
        Dim deck As New Rectangle

        ' declare variables
        Dim dblPriceSqFt As Double
        Dim intSqFt As Integer
        Dim dblCost As Double
        'Dim intDeckLen As Integer
        'Dim intDeckWid As Integer
        ' assign values to the object's Public properties
        Integer.TryParse(lstLength.SelectedItem.ToString, deck.Lenght)
        Integer.TryParse(lstWidth.SelectedItem.ToString, deck.Width)
        Double.TryParse(lstPrice.SelectedItem.ToString, dblPriceSqFt)

        'deck = New Rectangle(intDeckLen, intDeckWid)
        ' calculate the square feet
        intSqFt = deck.GetArea
        ' calculate the deck cost
        dblCost = intSqFt * dblPriceSqFt


        ' display output
        lblSquareFeet.Text = intSqFt.ToString
        lblCost.Text = dblCost.ToString("C2")

    End Sub

    Private Sub ClearLabels(sender As Object, e As EventArgs) Handles lstLength.SelectedValueChanged, lstWidth.SelectedValueChanged, lstPrice.SelectedValueChanged
        lblSquareFeet.Text = String.Empty
        lblCost.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        ' fills the list boxes with data and then selects a default item

        For intNums As Integer = 12 To 36 Step 2
            lstLength.Items.Add(intNums.ToString)
            lstWidth.Items.Add(intNums.ToString)
        Next intNums

        For dblPrices As Double = 5 To 25 Step 0.5
            lstPrice.Items.Add(dblPrices.ToString("N2"))
        Next dblPrices

        lstLength.SelectedIndex = 0
        lstWidth.SelectedIndex = 0
        lstPrice.SelectedItem = "10.00"
    End Sub
End Class
