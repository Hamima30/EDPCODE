﻿Public Class Form1

    Private Sub BtnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim decItem1, decItem2, decTotal, decSaving As Decimal
        'input
        Decimal.TryParse(txtItem1.Text, decItem1)
        Decimal.TryParse(txtItem2.Text, decItem2)
        'process
        decTotal = decItem1 + decItem2
        If decItem1 < decItem2 Then
            decSaving = decItem1 * 0.5
        Else
            decSaving = decItem2 * 0.5

        End If
        decTotal = decTotal - decSaving
        'output
        txtTotal.Text = decTotal.ToString("C2")
        MessageBox.Show(decSaving.ToString("C2"), "Savings", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub input_TextChanged(sender As Object, e As EventArgs) Handles txtItem2.TextChanged, txtItem1.TextChanged
        txtTotal.Clear()
    End Sub

    Private Sub input_Click(sender As Object, e As EventArgs) Handles txtItem2.Click, txtItem1.Click
        Dim t As TextBox = sender
        t.SelectAll()
    End Sub

    Private Sub validate_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtItem2.KeyPress, txtItem1.KeyPress
        Dim tb As TextBox = sender
        If Char.IsDigit(e.KeyChar) OrElse e.KeyChar = ControlChars.Back OrElse e.KeyChar = "." Then
            If e.KeyChar = "." AndAlso tb.Text.Contains(".") Then
                e.Handled = True
            Else
                e.Handled = False
            End If

        Else
            e.Handled = True
        End If
    End Sub


End Class
