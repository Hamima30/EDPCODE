﻿'Hamima A. Dalano on July 6,2020

Public Class RectangularPool
    Public lenght As Double
    Public width As Double
    Public Depth As Double

End Class
