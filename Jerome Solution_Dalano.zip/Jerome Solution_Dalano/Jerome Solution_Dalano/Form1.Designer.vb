﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblItemprice = New System.Windows.Forms.Label()
        Me.txtItemprice = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtDuetotal = New System.Windows.Forms.TextBox()
        Me.txtShipping = New System.Windows.Forms.TextBox()
        Me.txtSalestax = New System.Windows.Forms.TextBox()
        Me.txtSubtotal = New System.Windows.Forms.TextBox()
        Me.lblTotaldue = New System.Windows.Forms.Label()
        Me.lblShipping = New System.Windows.Forms.Label()
        Me.lblSalestax = New System.Windows.Forms.Label()
        Me.lblSubtotal = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.lblExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblItemprice
        '
        Me.lblItemprice.AutoSize = True
        Me.lblItemprice.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblItemprice.Location = New System.Drawing.Point(150, 28)
        Me.lblItemprice.Name = "lblItemprice"
        Me.lblItemprice.Size = New System.Drawing.Size(67, 15)
        Me.lblItemprice.TabIndex = 0
        Me.lblItemprice.Text = "&Item price:"
        '
        'txtItemprice
        '
        Me.txtItemprice.Location = New System.Drawing.Point(131, 46)
        Me.txtItemprice.Multiline = True
        Me.txtItemprice.Name = "txtItemprice"
        Me.txtItemprice.Size = New System.Drawing.Size(100, 32)
        Me.txtItemprice.TabIndex = 1
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtDuetotal)
        Me.GroupBox1.Controls.Add(Me.txtShipping)
        Me.GroupBox1.Controls.Add(Me.txtSalestax)
        Me.GroupBox1.Controls.Add(Me.txtSubtotal)
        Me.GroupBox1.Controls.Add(Me.lblTotaldue)
        Me.GroupBox1.Controls.Add(Me.lblShipping)
        Me.GroupBox1.Controls.Add(Me.lblSalestax)
        Me.GroupBox1.Controls.Add(Me.lblSubtotal)
        Me.GroupBox1.Location = New System.Drawing.Point(45, 105)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(261, 183)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "x"
        '
        'txtDuetotal
        '
        Me.txtDuetotal.Location = New System.Drawing.Point(86, 133)
        Me.txtDuetotal.Multiline = True
        Me.txtDuetotal.Name = "txtDuetotal"
        Me.txtDuetotal.Size = New System.Drawing.Size(150, 32)
        Me.txtDuetotal.TabIndex = 7
        '
        'txtShipping
        '
        Me.txtShipping.Location = New System.Drawing.Point(86, 95)
        Me.txtShipping.Multiline = True
        Me.txtShipping.Name = "txtShipping"
        Me.txtShipping.ReadOnly = True
        Me.txtShipping.Size = New System.Drawing.Size(150, 32)
        Me.txtShipping.TabIndex = 6
        '
        'txtSalestax
        '
        Me.txtSalestax.Location = New System.Drawing.Point(86, 57)
        Me.txtSalestax.Multiline = True
        Me.txtSalestax.Name = "txtSalestax"
        Me.txtSalestax.ReadOnly = True
        Me.txtSalestax.Size = New System.Drawing.Size(150, 32)
        Me.txtSalestax.TabIndex = 5
        '
        'txtSubtotal
        '
        Me.txtSubtotal.Location = New System.Drawing.Point(86, 19)
        Me.txtSubtotal.Multiline = True
        Me.txtSubtotal.Name = "txtSubtotal"
        Me.txtSubtotal.ReadOnly = True
        Me.txtSubtotal.Size = New System.Drawing.Size(150, 32)
        Me.txtSubtotal.TabIndex = 4
        '
        'lblTotaldue
        '
        Me.lblTotaldue.AutoSize = True
        Me.lblTotaldue.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotaldue.Location = New System.Drawing.Point(6, 131)
        Me.lblTotaldue.Name = "lblTotaldue"
        Me.lblTotaldue.Size = New System.Drawing.Size(68, 20)
        Me.lblTotaldue.TabIndex = 3
        Me.lblTotaldue.Text = "Total due:"
        '
        'lblShipping
        '
        Me.lblShipping.AutoSize = True
        Me.lblShipping.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShipping.Location = New System.Drawing.Point(8, 100)
        Me.lblShipping.Name = "lblShipping"
        Me.lblShipping.Size = New System.Drawing.Size(66, 20)
        Me.lblShipping.TabIndex = 2
        Me.lblShipping.Text = "Shipping:"
        '
        'lblSalestax
        '
        Me.lblSalestax.AutoSize = True
        Me.lblSalestax.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSalestax.Location = New System.Drawing.Point(6, 63)
        Me.lblSalestax.Name = "lblSalestax"
        Me.lblSalestax.Size = New System.Drawing.Size(68, 20)
        Me.lblSalestax.TabIndex = 1
        Me.lblSalestax.Text = "Sales tax:"
        '
        'lblSubtotal
        '
        Me.lblSubtotal.AutoSize = True
        Me.lblSubtotal.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubtotal.Location = New System.Drawing.Point(13, 27)
        Me.lblSubtotal.Name = "lblSubtotal"
        Me.lblSubtotal.Size = New System.Drawing.Size(61, 20)
        Me.lblSubtotal.TabIndex = 0
        Me.lblSubtotal.Text = "Subtotal:"
        '
        'btnCalculate
        '
        Me.btnCalculate.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.Location = New System.Drawing.Point(55, 339)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 40)
        Me.btnCalculate.TabIndex = 3
        Me.btnCalculate.Text = "&Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'lblExit
        '
        Me.lblExit.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblExit.Location = New System.Drawing.Point(195, 339)
        Me.lblExit.Name = "lblExit"
        Me.lblExit.Size = New System.Drawing.Size(75, 40)
        Me.lblExit.TabIndex = 4
        Me.lblExit.Text = "E&xit"
        Me.lblExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(370, 450)
        Me.Controls.Add(Me.lblExit)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtItemprice)
        Me.Controls.Add(Me.lblItemprice)
        Me.Name = "Form1"
        Me.Text = "Jerome's"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblItemprice As Label
    Friend WithEvents txtItemprice As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lblShipping As Label
    Friend WithEvents lblSalestax As Label
    Friend WithEvents lblSubtotal As Label
    Friend WithEvents lblTotaldue As Label
    Friend WithEvents txtDuetotal As TextBox
    Friend WithEvents txtShipping As TextBox
    Friend WithEvents txtSalestax As TextBox
    Friend WithEvents txtSubtotal As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents lblExit As Button
End Class
