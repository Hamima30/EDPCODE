﻿Public Class Form1
    Private dblSubTotal As Decimal = 0

    Private Sub BtnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim dblItemPrice, dblSalesTax, dblShipping, dblTotalDue As Decimal

        'input
        Decimal.TryParse(txtItemprice.Text, dblItemPrice)
        txtItemprice.Clear()
        'process
        dblSubTotal = dblSubTotal + dblItemPrice
        dblSalesTax = dblSubTotal * 0.05
        If dblSubTotal < 100 Then
            dblShipping = 6.5
        Else
            dblShipping = 0
        End If
        dblTotalDue = dblSubTotal + dblSalesTax + dblShipping

        'output
        txtSubtotal.Text = dblSubTotal.ToString("C2")
        txtSalestax.Text = dblSalesTax.ToString("C2")
        txtShipping.Text = dblShipping.ToString("C2")
        txtDuetotal.Text = dblTotalDue.ToString("C2")
    End Sub

End Class
