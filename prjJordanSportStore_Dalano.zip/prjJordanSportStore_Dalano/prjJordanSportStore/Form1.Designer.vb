﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.lblYs = New System.Windows.Forms.Label()
        Me.lblWeekly = New System.Windows.Forms.Label()
        Me.lblBw = New System.Windows.Forms.Label()
        Me.txtYs = New System.Windows.Forms.TextBox()
        Me.txtBw = New System.Windows.Forms.TextBox()
        Me.txtW = New System.Windows.Forms.TextBox()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.Print = New Microsoft.VisualBasic.PowerPacks.Printing.PrintForm(Me.components)
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblYs
        '
        Me.lblYs.AutoSize = True
        Me.lblYs.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYs.Location = New System.Drawing.Point(6, 16)
        Me.lblYs.Name = "lblYs"
        Me.lblYs.Size = New System.Drawing.Size(84, 15)
        Me.lblYs.TabIndex = 0
        Me.lblYs.Text = "1 Year Salary:"
        '
        'lblWeekly
        '
        Me.lblWeekly.AutoSize = True
        Me.lblWeekly.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWeekly.Location = New System.Drawing.Point(34, 48)
        Me.lblWeekly.Name = "lblWeekly"
        Me.lblWeekly.Size = New System.Drawing.Size(56, 15)
        Me.lblWeekly.TabIndex = 1
        Me.lblWeekly.Text = "Weekly:"
        '
        'lblBw
        '
        Me.lblBw.AutoSize = True
        Me.lblBw.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBw.Location = New System.Drawing.Point(27, 82)
        Me.lblBw.Name = "lblBw"
        Me.lblBw.Size = New System.Drawing.Size(63, 15)
        Me.lblBw.TabIndex = 2
        Me.lblBw.Text = "BiWeekly:"
        '
        'txtYs
        '
        Me.txtYs.Location = New System.Drawing.Point(108, 11)
        Me.txtYs.Name = "txtYs"
        Me.txtYs.Size = New System.Drawing.Size(168, 20)
        Me.txtYs.TabIndex = 3
        '
        'txtBw
        '
        Me.txtBw.Location = New System.Drawing.Point(108, 77)
        Me.txtBw.Name = "txtBw"
        Me.txtBw.Size = New System.Drawing.Size(168, 20)
        Me.txtBw.TabIndex = 4
        '
        'txtW
        '
        Me.txtW.Location = New System.Drawing.Point(108, 43)
        Me.txtW.Name = "txtW"
        Me.txtW.Size = New System.Drawing.Size(168, 20)
        Me.txtW.TabIndex = 5
        '
        'btnCalc
        '
        Me.btnCalc.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalc.Location = New System.Drawing.Point(24, 28)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(82, 54)
        Me.btnCalc.TabIndex = 6
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(222, 28)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(82, 54)
        Me.btnClear.TabIndex = 7
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(389, 33)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "JORDAN SPORTS STORE"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(139, 13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(404, 52)
        Me.GroupBox1.TabIndex = 9
        Me.GroupBox1.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lblYs)
        Me.GroupBox2.Controls.Add(Me.lblWeekly)
        Me.GroupBox2.Controls.Add(Me.lblBw)
        Me.GroupBox2.Controls.Add(Me.txtYs)
        Me.GroupBox2.Controls.Add(Me.txtBw)
        Me.GroupBox2.Controls.Add(Me.txtW)
        Me.GroupBox2.Location = New System.Drawing.Point(93, 99)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(498, 103)
        Me.GroupBox2.TabIndex = 10
        Me.GroupBox2.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnPrint)
        Me.GroupBox3.Controls.Add(Me.btnCalc)
        Me.GroupBox3.Controls.Add(Me.btnClear)
        Me.GroupBox3.Location = New System.Drawing.Point(123, 238)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(310, 100)
        Me.GroupBox3.TabIndex = 11
        Me.GroupBox3.TabStop = False
        '
        'btnPrint
        '
        Me.btnPrint.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrint.Location = New System.Drawing.Point(122, 28)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(82, 54)
        Me.btnPrint.TabIndex = 8
        Me.btnPrint.Text = "Print"
        Me.btnPrint.UseVisualStyleBackColor = True
        '
        'Print
        '
        Me.Print.DocumentName = "document"
        Me.Print.Form = Me
        Me.Print.PrintAction = System.Drawing.Printing.PrintAction.PrintToPreview
        Me.Print.PrinterSettings = CType(resources.GetObject("Print.PrinterSettings"), System.Drawing.Printing.PrinterSettings)
        Me.Print.PrintFileName = Nothing
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(677, 450)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Jordan Sports Store"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblYs As Label
    Friend WithEvents lblWeekly As Label
    Friend WithEvents lblBw As Label
    Friend WithEvents txtYs As TextBox
    Friend WithEvents txtBw As TextBox
    Friend WithEvents txtW As TextBox
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents btnPrint As Button
    Friend WithEvents Print As PowerPacks.Printing.PrintForm
End Class
