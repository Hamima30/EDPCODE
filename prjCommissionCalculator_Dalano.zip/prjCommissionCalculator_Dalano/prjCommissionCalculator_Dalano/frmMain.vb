﻿Public Class frmMain
    Private Sub BtnRate8_Click(sender As Object, e As EventArgs) Handles btnRate8.Click
        Dim dblSales As Double
        Dim dblComm8 As Double
        Double.TryParse(txtSales.Text, dblSales)
        dblComm8 = dblSales * 0.08
        txtComm.Text = Convert.ToString(dblComm8)
    End Sub

    Private Sub BtnRate10_Click(sender As Object, e As EventArgs) Handles btnRate10.Click
        Dim dblSales As Double
        Dim dblComm10 As Double
        Double.TryParse(txtSales.Text, dblSales)
        dblComm10 = dblSales * 0.01
        txtComm.Text = Convert.ToString(dblComm10)

    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
