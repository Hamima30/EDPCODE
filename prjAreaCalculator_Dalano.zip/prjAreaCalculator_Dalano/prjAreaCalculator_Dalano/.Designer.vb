﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.lblCr = New System.Windows.Forms.Label()
        Me.txtCa = New System.Windows.Forms.TextBox()
        Me.txtCr = New System.Windows.Forms.TextBox()
        Me.txtExit = New System.Windows.Forms.Button()
        Me.lblCa = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCalc
        '
        Me.btnCalc.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalc.Location = New System.Drawing.Point(57, 99)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(100, 23)
        Me.btnCalc.TabIndex = 0
        Me.btnCalc.Text = "&Calculate Area"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'lblCr
        '
        Me.lblCr.AutoSize = True
        Me.lblCr.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCr.Location = New System.Drawing.Point(54, 45)
        Me.lblCr.Name = "lblCr"
        Me.lblCr.Size = New System.Drawing.Size(92, 15)
        Me.lblCr.TabIndex = 1
        Me.lblCr.Text = "Circle’s radius:"
        '
        'txtCa
        '
        Me.txtCa.Location = New System.Drawing.Point(181, 63)
        Me.txtCa.Name = "txtCa"
        Me.txtCa.ReadOnly = True
        Me.txtCa.Size = New System.Drawing.Size(100, 20)
        Me.txtCa.TabIndex = 2
        '
        'txtCr
        '
        Me.txtCr.Location = New System.Drawing.Point(57, 63)
        Me.txtCr.Name = "txtCr"
        Me.txtCr.Size = New System.Drawing.Size(89, 20)
        Me.txtCr.TabIndex = 3
        '
        'txtExit
        '
        Me.txtExit.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtExit.Location = New System.Drawing.Point(181, 99)
        Me.txtExit.Name = "txtExit"
        Me.txtExit.Size = New System.Drawing.Size(75, 23)
        Me.txtExit.TabIndex = 4
        Me.txtExit.Text = "E&xit"
        Me.txtExit.UseVisualStyleBackColor = True
        '
        'lblCa
        '
        Me.lblCa.AutoSize = True
        Me.lblCa.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCa.Location = New System.Drawing.Point(178, 45)
        Me.lblCa.Name = "lblCa"
        Me.lblCa.Size = New System.Drawing.Size(82, 15)
        Me.lblCa.TabIndex = 5
        Me.lblCa.Text = "Circle’s area:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(327, 171)
        Me.Controls.Add(Me.lblCa)
        Me.Controls.Add(Me.txtExit)
        Me.Controls.Add(Me.txtCr)
        Me.Controls.Add(Me.txtCa)
        Me.Controls.Add(Me.lblCr)
        Me.Controls.Add(Me.btnCalc)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalc As Button
    Friend WithEvents lblCr As Label
    Friend WithEvents txtCa As TextBox
    Friend WithEvents txtCr As TextBox
    Friend WithEvents txtExit As Button
    Friend WithEvents lblCa As Label
End Class
