﻿Public Class Form1


    Private Sub BtnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Const dblPI As Double = 3.141593
        Dim dblRadius As Double
        Dim dblArea As Double
        Double.TryParse(txtCr.Text, dblRadius)
        dblArea = dblPI * dblRadius * dblRadius
        txtCa.Text = Format(dblArea, "standard")

    End Sub

    Private Sub TxtExit_Click(sender As Object, e As EventArgs) Handles txtExit.Click
        Me.Close()
    End Sub
End Class
