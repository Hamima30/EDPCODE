﻿' Name:         Gross Project
' Purpose:      Displays gross pay
' Programmer:   Hamima A. Dalano on June 21,2020

Option Explicit On
Option Infer Off
Option Strict On

Public Class frmMain
    Private Sub btnAndAlso_Click(sender As Object, e As EventArgs) Handles btnAndAlso.Click
        ' calculate gross pay

        Dim decHours As Decimal
        Dim decRate As Decimal
        Dim decGross As Decimal

        Decimal.TryParse(txtHours.Text, decHours)
        Decimal.TryParse(txtRate.Text, decRate)

        If decHours > 0 AndAlso decRate < 40 Then
            decGross = decHours * decRate
            lblGross.Text = decGross.ToString("C2")

        Else
            lblGross.Text = "N/A"

        End If
    End Sub

    Private Sub btnOrElse_Click(sender As Object, e As EventArgs) Handles btnOrElse.Click
        ' calculate gross pay

        Dim decHours As Decimal
        Dim decRate As Decimal
        Dim decGross As Decimal

        Decimal.TryParse(txtHours.Text, decHours)
        Decimal.TryParse(txtRate.Text, decRate)

        If decHours < 0 OrElse decRate > 40 Then
            lblGross.Text = "N/A"
        Else
            decGross = decHours * decRate
            lblGross.Text = decGross.ToString("C2")

        End If

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub ClearGross(sender As Object, e As EventArgs) Handles txtHours.TextChanged, txtRate.TextChanged
        lblGross.Text = String.Empty
    End Sub
End Class
