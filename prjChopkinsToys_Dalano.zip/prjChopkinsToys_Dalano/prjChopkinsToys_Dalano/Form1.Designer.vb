﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblInvoice = New System.Windows.Forms.Label()
        Me.lblDo = New System.Windows.Forms.Label()
        Me.txtDo = New System.Windows.Forms.TextBox()
        Me.lbl12pack = New System.Windows.Forms.Label()
        Me.lbl5pack = New System.Windows.Forms.Label()
        Me.lbl2pack = New System.Windows.Forms.Label()
        Me.txt12pack1 = New System.Windows.Forms.TextBox()
        Me.txt5pack1 = New System.Windows.Forms.TextBox()
        Me.txt2pack1 = New System.Windows.Forms.TextBox()
        Me.txt12pack2 = New System.Windows.Forms.TextBox()
        Me.txt5pack2 = New System.Windows.Forms.TextBox()
        Me.txt2pack2 = New System.Windows.Forms.TextBox()
        Me.lblShipping = New System.Windows.Forms.Label()
        Me.txtShipping = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtSalesTotal = New System.Windows.Forms.TextBox()
        Me.txtSalesTotal2 = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblInvoice
        '
        Me.lblInvoice.AutoSize = True
        Me.lblInvoice.Font = New System.Drawing.Font("Arial", 24.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInvoice.Location = New System.Drawing.Point(93, 19)
        Me.lblInvoice.Name = "lblInvoice"
        Me.lblInvoice.Size = New System.Drawing.Size(126, 36)
        Me.lblInvoice.TabIndex = 0
        Me.lblInvoice.Text = "Invoice"
        '
        'lblDo
        '
        Me.lblDo.AutoSize = True
        Me.lblDo.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDo.Location = New System.Drawing.Point(60, 83)
        Me.lblDo.Name = "lblDo"
        Me.lblDo.Size = New System.Drawing.Size(84, 15)
        Me.lblDo.TabIndex = 1
        Me.lblDo.Text = "&Date ordered:"
        '
        'txtDo
        '
        Me.txtDo.Location = New System.Drawing.Point(150, 83)
        Me.txtDo.Name = "txtDo"
        Me.txtDo.Size = New System.Drawing.Size(120, 20)
        Me.txtDo.TabIndex = 2
        '
        'lbl12pack
        '
        Me.lbl12pack.AutoSize = True
        Me.lbl12pack.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl12pack.Location = New System.Drawing.Point(60, 109)
        Me.lbl12pack.Name = "lbl12pack"
        Me.lbl12pack.Size = New System.Drawing.Size(55, 15)
        Me.lbl12pack.TabIndex = 3
        Me.lbl12pack.Text = "&12 pack:"
        '
        'lbl5pack
        '
        Me.lbl5pack.AutoSize = True
        Me.lbl5pack.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5pack.Location = New System.Drawing.Point(60, 135)
        Me.lbl5pack.Name = "lbl5pack"
        Me.lbl5pack.Size = New System.Drawing.Size(48, 15)
        Me.lbl5pack.TabIndex = 4
        Me.lbl5pack.Text = "&5 pack:"
        '
        'lbl2pack
        '
        Me.lbl2pack.AutoSize = True
        Me.lbl2pack.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2pack.Location = New System.Drawing.Point(60, 159)
        Me.lbl2pack.Name = "lbl2pack"
        Me.lbl2pack.Size = New System.Drawing.Size(48, 15)
        Me.lbl2pack.TabIndex = 5
        Me.lbl2pack.Text = "&2 pack:"
        '
        'txt12pack1
        '
        Me.txt12pack1.Location = New System.Drawing.Point(114, 109)
        Me.txt12pack1.Name = "txt12pack1"
        Me.txt12pack1.Size = New System.Drawing.Size(56, 20)
        Me.txt12pack1.TabIndex = 6
        '
        'txt5pack1
        '
        Me.txt5pack1.Location = New System.Drawing.Point(114, 135)
        Me.txt5pack1.Name = "txt5pack1"
        Me.txt5pack1.Size = New System.Drawing.Size(56, 20)
        Me.txt5pack1.TabIndex = 7
        '
        'txt2pack1
        '
        Me.txt2pack1.Location = New System.Drawing.Point(114, 161)
        Me.txt2pack1.Name = "txt2pack1"
        Me.txt2pack1.Size = New System.Drawing.Size(56, 20)
        Me.txt2pack1.TabIndex = 8
        '
        'txt12pack2
        '
        Me.txt12pack2.Location = New System.Drawing.Point(176, 109)
        Me.txt12pack2.Name = "txt12pack2"
        Me.txt12pack2.Size = New System.Drawing.Size(92, 20)
        Me.txt12pack2.TabIndex = 9
        '
        'txt5pack2
        '
        Me.txt5pack2.Location = New System.Drawing.Point(176, 135)
        Me.txt5pack2.Name = "txt5pack2"
        Me.txt5pack2.Size = New System.Drawing.Size(92, 20)
        Me.txt5pack2.TabIndex = 10
        '
        'txt2pack2
        '
        Me.txt2pack2.Location = New System.Drawing.Point(176, 161)
        Me.txt2pack2.Name = "txt2pack2"
        Me.txt2pack2.Size = New System.Drawing.Size(92, 20)
        Me.txt2pack2.TabIndex = 11
        '
        'lblShipping
        '
        Me.lblShipping.AutoSize = True
        Me.lblShipping.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShipping.Location = New System.Drawing.Point(74, 204)
        Me.lblShipping.Name = "lblShipping"
        Me.lblShipping.Size = New System.Drawing.Size(59, 15)
        Me.lblShipping.TabIndex = 12
        Me.lblShipping.Text = "Shipping:"
        '
        'txtShipping
        '
        Me.txtShipping.Location = New System.Drawing.Point(176, 204)
        Me.txtShipping.Name = "txtShipping"
        Me.txtShipping.Size = New System.Drawing.Size(92, 20)
        Me.txtShipping.TabIndex = 13
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(31, 228)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 15)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Sales totals:"
        '
        'txtSalesTotal
        '
        Me.txtSalesTotal.Location = New System.Drawing.Point(114, 228)
        Me.txtSalesTotal.Name = "txtSalesTotal"
        Me.txtSalesTotal.ReadOnly = True
        Me.txtSalesTotal.Size = New System.Drawing.Size(56, 20)
        Me.txtSalesTotal.TabIndex = 15
        '
        'txtSalesTotal2
        '
        Me.txtSalesTotal2.Location = New System.Drawing.Point(176, 228)
        Me.txtSalesTotal2.Name = "txtSalesTotal2"
        Me.txtSalesTotal2.Size = New System.Drawing.Size(92, 20)
        Me.txtSalesTotal2.TabIndex = 16
        '
        'btnCalculate
        '
        Me.btnCalculate.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.Location = New System.Drawing.Point(33, 271)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 17
        Me.btnCalculate.Text = "&Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(126, 271)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 18
        Me.btnClear.Text = "C&lear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(217, 271)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 19
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(333, 341)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtSalesTotal2)
        Me.Controls.Add(Me.txtSalesTotal)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtShipping)
        Me.Controls.Add(Me.lblShipping)
        Me.Controls.Add(Me.txt2pack2)
        Me.Controls.Add(Me.txt5pack2)
        Me.Controls.Add(Me.txt12pack2)
        Me.Controls.Add(Me.txt2pack1)
        Me.Controls.Add(Me.txt5pack1)
        Me.Controls.Add(Me.txt12pack1)
        Me.Controls.Add(Me.lbl2pack)
        Me.Controls.Add(Me.lbl5pack)
        Me.Controls.Add(Me.lbl12pack)
        Me.Controls.Add(Me.txtDo)
        Me.Controls.Add(Me.lblDo)
        Me.Controls.Add(Me.lblInvoice)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Chopkins Toys"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblInvoice As Label
    Friend WithEvents lblDo As Label
    Friend WithEvents txtDo As TextBox
    Friend WithEvents lbl12pack As Label
    Friend WithEvents lbl5pack As Label
    Friend WithEvents lbl2pack As Label
    Friend WithEvents txt12pack1 As TextBox
    Friend WithEvents txt5pack1 As TextBox
    Friend WithEvents txt2pack1 As TextBox
    Friend WithEvents txt12pack2 As TextBox
    Friend WithEvents txt5pack2 As TextBox
    Friend WithEvents txt2pack2 As TextBox
    Friend WithEvents lblShipping As Label
    Friend WithEvents txtShipping As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtSalesTotal As TextBox
    Friend WithEvents txtSalesTotal2 As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
